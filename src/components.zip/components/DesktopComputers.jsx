
import React from 'react';
import { Link } from 'react-router-dom';
import ScrollReveal from './ScrollReveal';

const desktopOptions = [
  {
    title: 'Business Desktop PCs',
    description: 'Reliable desktop computers for offices and professional work.',
    icon: 'bi-pc-display',
  },
  {
    title: 'Gaming PCs',
    description: 'Powerful desktop systems for gaming and demanding tasks.',
    icon: 'bi-controller',
  },
  {
    title: 'Custom Built PCs',
    description: 'Desktop computers configured according to your requirements.',
    icon: 'bi-tools',
  },
];

function DesktopComputers() {
  return (
    <ScrollReveal>
      <section className="py-5">
        <div className="container">
          <div className="text-center mb-5">
            <p className="text-danger fw-bold">DESKTOP SOLUTIONS</p>
            <h2 className="fw-bold">PCs & Desktop Computers</h2>
            <p className="text-secondary">
              Find reliable desktop solutions for business, gaming and everyday use.
            </p>
          </div>

          <div className="row g-4">
            {desktopOptions.map((item) => (
              <div className="col-md-4" key={item.title}>
                <div className="card h-100 border-0 shadow-sm text-center p-4">
                  <div className="mb-3">
                    <i
                      className={`bi ${item.icon} text-danger`}
                      style={{ fontSize: '45px' }}
                    ></i>
                  </div>

                  <h5 className="fw-bold">{item.title}</h5>

                  <p className="text-secondary">
                    {item.description}
                  </p>

                  <Link
                    to="/contact"
                    className="btn btn-outline-danger mt-auto"
                  >
                    Enquire Now
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </ScrollReveal>
  );
}

export default DesktopComputers;
