
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const API = "http://localhost:5000/api/categories";

function ProductCategories() {
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch(API);
        const data = await response.json();

        if (response.ok) {
          setCategories(data.categories || []);
        }
      } catch (error) {
        console.error("Failed to load categories:", error);
      }
    };

    fetchCategories();
  }, []);

  if (!categories.length) return null;

  return (
    <section className="py-5">
      <div className="container">
        <div className="text-center mb-4">
          <p className="text-danger fw-bold mb-2">
            SHOP BY CATEGORY
          </p>
          <h2 className="fw-bold">Product Categories</h2>
          <p className="text-secondary">
            Explore our available product categories.
          </p>
        </div>

        <div className="row g-3">
          {categories.map((category) => (
            <div className="col-6 col-md-4 col-lg-3" key={category._id}>
              <Link
                to={`/products?category=${encodeURIComponent(category.name)}`}
                className="text-decoration-none"
              >
                <div className="card h-100 shadow-sm border-0 text-center p-4">
                  <h5 className="fw-bold text-dark mb-0">
                    {category.name}
                  </h5>
                </div>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default ProductCategories;
