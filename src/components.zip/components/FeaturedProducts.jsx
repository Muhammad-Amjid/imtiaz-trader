
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ScrollReveal from "./ScrollReveal";

const API_URL = "http://localhost:5000/api/products";
const SERVER_URL = "http://localhost:5000";

const fallbackImage =
  "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800";

function getImageUrl(image) {
  if (!image) return fallbackImage;

  return image.startsWith("http")
    ? image
    : `${SERVER_URL}${image}`;
}

function FeaturedProducts() {
  const navigate = useNavigate();

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await fetch(API_URL);
        const data = await response.json();

        if (!response.ok || !data.success) {
          throw new Error("Unable to load products.");
        }

        const availableProducts = (data.products || []).filter(
          (product) => product.available !== false
        );

        setProducts(availableProducts);
      } catch (error) {
        console.error("Featured products error:", error);
        setError("Unable to load products. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, []);

  const selectedProducts = products
    .filter((product) => product.featured === true)
    .slice(0, 6);

  const featuredProducts =
    selectedProducts.length > 0
      ? selectedProducts
      : products.slice(0, 6);

  return (
    <ScrollReveal>
      <section className="py-5">
        <div className="container">
          <div className="text-center mb-5">
            <p className="text-danger fw-bold">OUR PRODUCTS</p>
            <h2 className="fw-bold">Featured Laptops</h2>
            <p className="text-secondary">
              Explore selected laptops available at Imtiaz Trader.
            </p>
          </div>

          <div className="row g-4">
            {loading ? (
              <div className="col-12 text-center">
                <p className="text-secondary">Loading products...</p>
              </div>
            ) : error ? (
              <div className="col-12 text-center">
                <p className="text-danger">{error}</p>
              </div>
            ) : featuredProducts.length > 0 ? (
              featuredProducts.map((product) => {
                const imagePath =
                  product.images?.[0] || product.image;

                return (
                  <div
                    className="col-12 col-sm-6 col-lg-4"
                    key={product._id}
                  >
                    <div className="card product-card h-100 border-0 shadow-sm overflow-hidden">
                      <img
                        src={getImageUrl(imagePath)}
                        className="card-img-top"
                        alt={product.name}
                        loading="lazy"
                        onError={(event) => {
                          event.currentTarget.onerror = null;
                          event.currentTarget.src = fallbackImage;
                        }}
                        style={{
                          height: "220px",
                          objectFit: "contain",
                          padding: "15px",
                          backgroundColor: "#f8f8f8",
                        }}
                      />

                      <div className="card-body p-4 d-flex flex-column">
                        {product.condition && (
                          <span className="badge bg-danger align-self-start mb-3">
                            {product.condition}
                          </span>
                        )}

                        <h5 className="fw-bold">{product.name}</h5>

                        <p className="text-secondary">
                          {product.description}
                        </p>

                        <button
                          type="button"
                          className="btn btn-outline-danger w-100 mt-auto"
                          onClick={() =>
                            navigate(`/product/${product._id}`)
                          }
                        >
                          View Details
                          <i className="bi bi-arrow-right ms-2"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="col-12 text-center">
                <p className="text-secondary">
                  New featured products will be available soon.
                </p>
              </div>
            )}
          </div>

          <div className="text-center mt-4">
            <button
              type="button"
              className="btn btn-danger px-4"
              onClick={() => navigate("/products")}
            >
              View All Products
            </button>
          </div>
        </div>
      </section>
    </ScrollReveal>
  );
}

export default FeaturedProducts;
