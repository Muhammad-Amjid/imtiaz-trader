
import React from "react";
import { Link } from "react-router-dom";
import { brands } from "../data/brands";
import ScrollReveal from "./ScrollReveal";

const brandImages = {
  hp: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=700",
  dell: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=700",
  lenovo: "https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=700",
  thinkpad: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=700",
  dynabook: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=700",
  macbook: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=700",
};

function Categories() {
  return (
    <ScrollReveal>
      <section className="brand-section py-5">
        <div className="container">
          <div className="text-center mb-5">
            <p className="text-danger fw-bold mb-2">
              OUR LAPTOP BRANDS
            </p>
            <h2 className="fw-bold">Explore Our Brands</h2>
            <p className="text-secondary">
              Discover quality laptops from your favourite brands.
            </p>
          </div>

          <div className="row g-4">
            {brands.map((brand) => (
              <div className="col-12 col-sm-6 col-md-4" key={brand.id}>
                <Link
                  to={`/brand/${encodeURIComponent(brand.name)}`}
                  className="text-decoration-none text-dark"
                >
                  <div className="brand-card bg-white h-100 shadow-sm">
                    <div className="brand-image-wrapper">
                      <img
                        src={brandImages[brand.id]}
                        alt={`${brand.name} laptop`}
                        className="brand-image"
                        loading="lazy"
                      />
                    </div>

                    <div className="text-center p-3">
                      <h5 className="fw-bold mb-2">
                        {brand.name}
                      </h5>

                      <p className="text-secondary mb-3">
                        {brand.description}
                      </p>

                      <span className="text-danger fw-semibold">
                        Explore Products →
                      </span>
                    </div>
                  </div>
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </ScrollReveal>
  );
}

export default Categories;
